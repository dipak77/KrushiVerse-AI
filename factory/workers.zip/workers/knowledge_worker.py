"""Knowledge Expert: build the existing provenance-aware Mini KG."""

from factory.workers.base_worker import MiniAdapterWorker, module_main


class KnowledgeWorker(MiniAdapterWorker):
    mini_worker_id = "W-KGBUILD"


if __name__ == "__main__":
    raise SystemExit(module_main(KnowledgeWorker))
