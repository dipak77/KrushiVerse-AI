"""Synthetic Expert: run QA synth for fine-tuning data generation."""

from factory.workers.base_worker import MiniAdapterWorker, module_main


class SyntheticWorker(MiniAdapterWorker):
    mini_worker_id = "W-QASYNTH"
    needs_gpu = True


if __name__ == "__main__":
    raise SystemExit(module_main(SyntheticWorker))
