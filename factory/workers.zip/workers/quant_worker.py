"""Quant Expert: INT8 quantization and ONNX runtime export."""

from factory.workers.base_worker import MiniAdapterWorker, module_main


class QuantWorker(MiniAdapterWorker):
    mini_worker_id = "W-QUANT"
    needs_gpu = False


if __name__ == "__main__":
    raise SystemExit(module_main(QuantWorker))
