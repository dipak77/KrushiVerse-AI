"""Tokenizer adapter for the 8k Unigram v2 vocabulary."""

from factory.workers.base_worker import MiniAdapterWorker, module_main


class TokenizerWorker(MiniAdapterWorker):
    mini_worker_id = "W-TOKEN"


if __name__ == "__main__":
    raise SystemExit(module_main(TokenizerWorker))
