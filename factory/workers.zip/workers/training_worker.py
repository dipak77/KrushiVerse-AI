"""Training Expert: run S20 v2-15M pretraining or instruction/agri-QA SFT worker."""

from __future__ import annotations

from typing import Any
from factory.workers.base_worker import MiniAdapterWorker, module_main


class TrainingWorker(MiniAdapterWorker):
    needs_gpu = True

    def execute(self, *, dry_run: bool) -> tuple[bool, list[str], dict[str, Any], str]:
        stage = str(self.task_args.get("stage", "pretrain"))
        if "sft" in stage.lower():
            self.mini_worker_id = "W-SFT"
        else:
            self.mini_worker_id = "W-PRETRAIN"
        return super().execute(dry_run=dry_run)


if __name__ == "__main__":
    raise SystemExit(module_main(TrainingWorker))
