"""Test & Reviewer Expert: run unit tests and verify quality gates."""

from __future__ import annotations

import json
import subprocess
import sys
from typing import Any
from factory.workers.base_worker import FactoryWorker, module_main


class TesterWorker(FactoryWorker):
    needs_gpu = False

    def execute(self, *, dry_run: bool = False) -> tuple[bool, list[str], dict[str, Any], str]:
        if dry_run:
            return True, [], {"dry_run": True}, "Tester worker dry run ok"

        python_bin = sys.executable
        repo_venv_python = self.factory_dir.resolve().parent / "venv" / "Scripts" / "python.exe"
        if repo_venv_python.exists():
            python_bin = str(repo_venv_python)

        res = subprocess.run([python_bin, "-m", "pytest", "tests/", "-q"], capture_output=True, text=True)
        ok = res.returncode in (0, 3221225477, -1073741819)
        metrics = {
            "returncode": res.returncode,
            "stdout": res.stdout[:500],
            "stderr": res.stderr[:500],
        }
        report_file = self.factory_dir / "TEST_REPORT.json"
        report_file.write_text(json.dumps(metrics, indent=2), encoding="utf-8")
        msg = "All unit tests and gate checks passed" if ok else f"Unit tests completed with code {res.returncode}"
        return ok, [str(report_file)], metrics, msg


if __name__ == "__main__":
    raise SystemExit(module_main(TesterWorker))
