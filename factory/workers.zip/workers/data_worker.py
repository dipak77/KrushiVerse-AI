"""Data Expert: maps v3 data preparation to the existing Mini S4 pipeline."""

from factory.workers.base_worker import MiniAdapterWorker, module_main


class DataWorker(MiniAdapterWorker):
    pipeline = "sprint4"


if __name__ == "__main__":
    raise SystemExit(module_main(DataWorker))
