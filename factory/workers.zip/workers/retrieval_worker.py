"""Retrieval Expert: test and index RAG capabilities."""

from factory.workers.base_worker import MiniAdapterWorker, module_main


class RetrievalWorker(MiniAdapterWorker):
    mini_worker_id = "W-RAG"
    needs_gpu = False


if __name__ == "__main__":
    raise SystemExit(module_main(RetrievalWorker))
