"""Base class that gives Mini workers factory state, heartbeat, and GPU cleanup."""

from __future__ import annotations

import argparse
import json
import traceback
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any

from factory.gpu_manager import GPUManager
from factory.state import TaskStore, atomic_write_json, utc_now


class FactoryWorker(ABC):
    needs_gpu = False

    def __init__(self, task_id: str, *, factory_dir: str | Path = "factory", gpu_reserved: bool = False) -> None:
        self.task_id = task_id
        self.factory_dir = Path(factory_dir)
        self.store = TaskStore(self.factory_dir)
        self.gpu = GPUManager(self.factory_dir)
        self.gpu_reserved = gpu_reserved
        self.task = self.store.task(task_id)
        self.task_args = dict(self.task.get("task_args") or {})

    def heartbeat(self, *, step: int | None = None, loss: float | None = None, message: str = "") -> None:
        payload = {
            "task_id": self.task_id,
            "worker": self.task.get("worker"),
            "step": step,
            "loss": loss,
            "message": message,
            "time": utc_now(),
        }
        atomic_write_json(self.factory_dir / "heartbeats" / f"{self.task_id}.json", payload)

    def _complete(self, artifacts: list[str], metrics: dict[str, Any]) -> None:
        def mutate(task: dict[str, Any]) -> None:
            task["status"] = "COMPLETED"
            task["finished_at"] = utc_now()
            task["artifacts"] = artifacts
            task["metrics"] = metrics
            task.pop("error", None)

        self.store.update_task(self.task_id, mutate)
        self.heartbeat(message="completed")

    def _fail(self, error: str) -> None:
        def mutate(task: dict[str, Any]) -> None:
            task["status"] = "FAILED"
            task["finished_at"] = utc_now()
            task["error"] = error

        self.store.update_task(self.task_id, mutate)
        self.heartbeat(message=f"failed: {error}")

    @abstractmethod
    def execute(self, *, dry_run: bool) -> tuple[bool, list[str], dict[str, Any], str]:
        """Return (ok, artifacts, metrics, message)."""

    def run(self, *, dry_run: bool = False) -> int:
        self.heartbeat(message="started")
        if self.needs_gpu and not self.gpu_reserved:
            if not self.gpu.acquire(self.task_id):
                self._fail("GPU reservation unavailable; planner must reserve GPU before launch")
                return 1
        if self.needs_gpu and not self.gpu.held_by(self.task_id):
            self._fail("GPU lock is not held by this task")
            return 1
        try:
            ok, artifacts, metrics, message = self.execute(dry_run=dry_run)
            if ok:
                self._complete(artifacts, metrics)
                return 0
            self._fail(message)
            return 1
        except Exception as exc:
            self._fail(f"{exc}\n{traceback.format_exc(limit=5)}")
            return 1
        finally:
            if self.needs_gpu:
                self.gpu.release(self.task_id)


class MiniAdapterWorker(FactoryWorker):
    """Execute one existing Mini worker or pipeline and preserve its report."""

    mini_worker_id: str | None = None
    pipeline: str | None = None

    def execute(self, *, dry_run: bool) -> tuple[bool, list[str], dict[str, Any], str]:
        if self.pipeline:
            from mini.orchestrator.dag import run_pipeline

            result = run_pipeline(self.pipeline, dry_run=dry_run)
            metrics = result.model_dump()
            artifacts = [artifact for step in result.steps for artifact in step.artifacts]
            return result.ok, artifacts, metrics, result.message
        if not self.mini_worker_id:
            raise RuntimeError("Factory adapter needs mini_worker_id or pipeline")
        from mini.workers.base import get_worker

        result = get_worker(self.mini_worker_id).run(dry_run=dry_run, **self.task_args)
        return result.ok, result.artifacts, result.metrics, result.message


def module_main(worker_type: type[FactoryWorker]) -> int:
    parser = argparse.ArgumentParser(description=f"Run {worker_type.__name__} under the autonomous factory")
    parser.add_argument("--task-id", required=True)
    parser.add_argument("--factory-dir", default="factory")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--gpu-reserved", action="store_true")
    args = parser.parse_args()
    return worker_type(args.task_id, factory_dir=args.factory_dir, gpu_reserved=args.gpu_reserved).run(
        dry_run=args.dry_run
    )
